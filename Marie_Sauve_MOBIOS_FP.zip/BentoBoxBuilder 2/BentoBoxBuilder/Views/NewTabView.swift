//
//  NewTabView.swift
//  BentoBoxBuilder
//
//  Created by Marie S on 2024-08-29.
//

import SwiftUI
import UIKit

//struct NewTabView: View {
    //    @State private var currentTab: TabItem = .home
    //
    //    private let tabs = [
    //        TabItem(title: "Home", iconName: "house"),
    //        TabItem(title: "Search", iconName: "magnifyingglass.circle"),
    //        TabItem(title: "Notify", iconName: "bell"),
    //        TabItem(title: "Cart", iconName: "bag"),
    //        TabItem(title: "Profile", iconName: "person")
    //    ]
    //
    //    var body: some View {
    //        CustomTabBarView(currentTab: $currentTab, tabs: tabs, position: .bottom) {
    //            switch currentTab {
    //            case .home:
    //                Text("Home View")
    //            case .search:
    //                Text("Search View")
    //            case .notify:
    //                Text("Notification View")
    //            case .cart:
    //                Text("Cart View")
    //            case .profile:
    //                Text("Profile View")
    //            default:
    //                Text("Home View")
    //            }
    //        }
    //    }
    //}
    //
    //extension TabItem {
    //    static let home = TabItem(title: "Home", iconName: "house")
    //    static let search = TabItem(title: "Search",iconName:"magnifyingglass.circle")
    //    static let notify = TabItem(title: "Notify", iconName: "bell")
    //    static let cart = TabItem(title: "Cart", iconName: "bag")
    //    static let profile = TabItem(title: "Profile", iconName: "person")
    //}
    
    //#Preview {
    //    NewTabView()
    //}

